import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import os

# Define file paths
raw_file_path = 'data\\raw\\open-meteo-13.11N80.25E15m.csv'
processed_dir = 'data\\processed'
output_file = os.path.join(processed_dir, 'cleaned_open-meteo-13.11N80.25E15m.csv')

# Create processed directory if it doesn't exist
os.makedirs(processed_dir, exist_ok=True)

# Load the dataset
df = pd.read_csv(raw_file_path)

# Display initial info to check structure
print("Initial dataset info:")
print(df.info())
print("\nInitial dataset head:")
print(df.head())

# Step 1: Handle missing values
# Fill missing numeric values with median (robust to outliers)
numeric_columns = df.select_dtypes(include=[np.number]).columns
df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].median())

# Step 2: Correct anomalies (e.g., unrealistic pressure values)
# Cap pressure_msl to a reasonable range (e.g., 900-1100 hPa)
df['pressure_msl (hPa)'] = df['pressure_msl (hPa)'].apply(
    lambda x: max(900, min(1100, x)) if pd.notnull(x) else x
)
df['surface_pressure (hPa)'] = df['surface_pressure (hPa)'].apply(
    lambda x: max(900, min(1100, x)) if pd.notnull(x) else x
)

# Step 3: Convert time column to datetime
df['time'] = pd.to_datetime(df['time'])

# Step 4: Handle inconsistent time intervals
# Ensure data is sorted by time
df = df.sort_values('time')

# Identify and fill gaps (e.g., if hourly data is missing)
expected_time_diff = pd.Timedelta(hours=1)
time_diff = df['time'].diff()
gaps = time_diff[time_diff > expected_time_diff]
if not gaps.empty:
    print("\nGaps detected in time series:")
    print(gaps)
    # Interpolate missing rows (if hourly data is expected)
    idx = pd.date_range(start=df['time'].min(), end=df['time'].max(), freq='H')
    df = df.set_index('time').reindex(idx).interpolate().reset_index().rename(columns={'index': 'time'})

# Step 5: Normalize numeric data for ML
scaler = MinMaxScaler()
df[numeric_columns] = scaler.fit_transform(df[numeric_columns])

# Step 6: Encode categorical data (e.g., weather_code)
# Map WMO weather codes to categories if needed (optional)
weather_code_map = {
    0: 'Clear', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast'
}
df['weather_code (wmo code)'] = df['weather_code (wmo code)'].map(weather_code_map).fillna(df['weather_code (wmo code)'])

# Step 7: Remove or handle duplicate rows
df = df.drop_duplicates(subset=['time'], keep='first')

# Step 8: Save cleaned and preprocessed data
df.to_csv(output_file, index=False)
print(f"\nCleaned dataset saved to {output_file}")

# Display final info to verify
print("\nCleaned dataset info:")
print(df.info())
print("\nCleaned dataset head:")
print(df.head())